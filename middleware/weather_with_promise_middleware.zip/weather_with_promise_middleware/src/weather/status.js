export const LOADING = 'loading';
export const SUCCESS = 'success';
export const FAILURE = 'failure';
