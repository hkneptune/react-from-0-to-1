import view from './view.js';

export {view};
