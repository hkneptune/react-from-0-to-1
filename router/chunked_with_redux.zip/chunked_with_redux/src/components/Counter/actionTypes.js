export const INCREMENT = 'counter/increment';

export const DECREMENT = 'counter/decrement';

