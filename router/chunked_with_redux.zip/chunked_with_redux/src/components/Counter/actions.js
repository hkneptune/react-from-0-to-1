import * as ActionTypes from './actionTypes.js';

export const increment = () => ({
  type: ActionTypes.INCREMENT
});

export const decrement = () => ({
  type: ActionTypes.DECREMENT
});
