import * as actions from './actions.js';
import reducer from './reducer.js';
import view, {stateKey} from './view.js';

export {actions, reducer, view, stateKey};
